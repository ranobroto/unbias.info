def hi(name)
    if name == 'Chelsea':
        print("hi chelsea")
    elif name =- 'Jordan':
        print('hi jordan')
    else:
        print('hi')

hi('jordan')